package edu_snhu_appointments;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AppointmentService {

    private final List<Appointment> appointments = new ArrayList<>();

    // Add new appointment (ID must be unique)
    public void addAppointment(String appointmentId, Date appointmentDate, String description) {

        // Check if ID is unique
        for (Appointment appt : appointments) {
            if (appt.getAppointmentId().equals(appointmentId)) {
                throw new IllegalArgumentException("Appointment ID already exists");
            }
        }

        Appointment newAppointment = new Appointment(appointmentId, appointmentDate, description);
        appointments.add(newAppointment);
    }

    // Delete appointment by ID
    public void deleteAppointment(String appointmentId) {
        appointments.removeIf(appt -> appt.getAppointmentId().equals(appointmentId));
    }

    // Helper method to find an appointment
    private Appointment getAppointmentById(String appointmentId) {
        for (Appointment appt : appointments) {
            if (appt.getAppointmentId().equals(appointmentId)) {
                return appt;
            }
        }
        return null;
    }

    // Update appointment date
    public void updateAppointmentDate(String appointmentId, Date appointmentDate) {
        Appointment appt = getAppointmentById(appointmentId);
        if (appt == null) {
            throw new IllegalArgumentException("Appointment not found");
        }
        appt.setAppointmentDate(appointmentDate);
    }

    // Update appointment description
    public void updateAppointmentDescription(String appointmentId, String description) {
        Appointment appt = getAppointmentById(appointmentId);
        if (appt == null) {
            throw new IllegalArgumentException("Appointment not found");
        }
        appt.setDescription(description);
    }

    // Getter mainly for tests
    public List<Appointment> getAppointments() {
        return new ArrayList<>(appointments);
    }
}
