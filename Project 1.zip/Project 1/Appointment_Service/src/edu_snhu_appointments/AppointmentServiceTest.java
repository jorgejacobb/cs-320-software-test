package edu_snhu_appointments;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    // Helper to create a future date
    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 1000 * 60 * 60); // +1 hour
    }

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = getFutureDate();

        service.addAppointment("1", futureDate, "Checkup");

        assertEquals(1, service.getAppointments().size());
        assertEquals("1", service.getAppointments().get(0).getAppointmentId());
    }

    @Test
    void testAddAppointmentDuplicateId() {
        AppointmentService service = new AppointmentService();
        Date futureDate = getFutureDate();

        service.addAppointment("1", futureDate, "First");

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("1", futureDate, "Second");
        });
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        Date futureDate = getFutureDate();

        service.addAppointment("1", futureDate, "Checkup");
        service.deleteAppointment("1");

        assertEquals(0, service.getAppointments().size());
    }

    @Test
    void testUpdateAppointmentDate() {
        AppointmentService service = new AppointmentService();
        Date futureDate = getFutureDate();

        service.addAppointment("1", futureDate, "Checkup");

        Date newFutureDate = new Date(System.currentTimeMillis() + 1000 * 60 * 120); // +2 hours
        service.updateAppointmentDate("1", newFutureDate);

        assertEquals(newFutureDate, service.getAppointments().get(0).getAppointmentDate());
    }

    @Test
    void testUpdateAppointmentDescription() {
        AppointmentService service = new AppointmentService();
        Date futureDate = getFutureDate();

        service.addAppointment("1", futureDate, "Old description");
        service.updateAppointmentDescription("1", "New description");

        assertEquals("New description", service.getAppointments().get(0).getDescription());
    }
}

