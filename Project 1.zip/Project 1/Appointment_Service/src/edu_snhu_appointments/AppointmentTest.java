package edu_snhu_appointments;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    // Helper to create a future date
    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 1000 * 60 * 60); // +1 hour
    }

    // Constructor works with valid data
    @Test
    void testAppointmentCreationValid() {
        Date futureDate = getFutureDate();
        Appointment appt = new Appointment("12345", futureDate, "Dentist appointment");

        assertEquals("12345", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
        assertEquals("Dentist appointment", appt.getDescription());
    }

    // ID null
    @Test
    void testAppointmentIdNull() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Description");
        });
    }

    // ID too long
    @Test
    void testAppointmentIdTooLong() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Description");
        });
    }

    // Date null
    @Test
    void testAppointmentDateNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Description");
        });
    }

    // Date in the past
    @Test
    void testAppointmentDateInPast() {
        Date pastDate = new Date(System.currentTimeMillis() - 1000 * 60 * 60); // -1 hour
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate, "Description");
        });
    }

    // Description null
    @Test
    void testAppointmentDescriptionNull() {
        Date futureDate = getFutureDate();
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, null);
        });
    }

    // Description too long
    @Test
    void testAppointmentDescriptionTooLong() {
        Date futureDate = getFutureDate();
        String longDescription = "This description is definitely longer than fifty characters total!";
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, longDescription);
        });
    }

    // Setter for date works
    @Test
    void testSetAppointmentDateValid() {
        Date futureDate = getFutureDate();
        Appointment appt = new Appointment("12345", futureDate, "Description");

        Date newFutureDate = new Date(System.currentTimeMillis() + 1000 * 60 * 120); // +2 hours
        appt.setAppointmentDate(newFutureDate);

        assertEquals(newFutureDate, appt.getAppointmentDate());
    }

    // Setter for description works
    @Test
    void testSetDescriptionValid() {
        Date futureDate = getFutureDate();
        Appointment appt = new Appointment("12345", futureDate, "Old description");

        appt.setDescription("New description");
        assertEquals("New description", appt.getDescription());
    }
}

