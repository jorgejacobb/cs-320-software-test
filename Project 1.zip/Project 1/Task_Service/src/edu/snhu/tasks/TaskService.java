package edu.snhu.tasks;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

    // In-memory storage: taskId -> Task
    private final Map<String, Task> tasks = new HashMap<>();

    // Add a task (ID must be unique)
    public Task addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }

        String id = task.getTaskId();
        if (tasks.containsKey(id)) {
            throw new IllegalArgumentException("Duplicate taskId: " + id);
        }

        tasks.put(id, task);
        return task;
    }

    // Delete task by ID
    public void deleteTask(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("taskId cannot be null");
        }

        if (tasks.remove(taskId) == null) {
            throw new IllegalArgumentException("No task with id: " + taskId);
        }
    }

    // Update name by ID
    public void updateName(String taskId, String name) {
        Task task = getTask(taskId);
        task.setName(name);
    }

    // Update description by ID
    public void updateDescription(String taskId, String description) {
        Task task = getTask(taskId);
        task.setDescription(description);
    }

    // Helper for tests / service
    public Task getTask(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("taskId cannot be null");
        }
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("No task with id: " + taskId);
        }
        return task;
    }
}
