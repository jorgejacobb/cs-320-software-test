package edu.snhu.tasks;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    void setup() {
        service = new TaskService();
    }

    @Test
    void addTaskRequiresUniqueId() {
        Task t1 = new Task("ID1", "Task1", "Desc1");
        Task t2 = new Task("ID1", "Task2", "Desc2");

        service.addTask(t1);
        assertThrows(IllegalArgumentException.class,
                () -> service.addTask(t2));
    }

    @Test
    void deleteTaskRemovesAndThenFailsIfMissing() {
        Task t = new Task("ID2", "Task2", "Desc2");
        service.addTask(t);

        service.deleteTask("ID2");

        assertThrows(IllegalArgumentException.class,
                () -> service.deleteTask("ID2"));
    }

    @Test
    void updateNameAndDescriptionById() {
        Task t = new Task("ID3", "OldName", "OldDesc");
        service.addTask(t);

        service.updateName("ID3", "NewName");
        service.updateDescription("ID3", "NewDesc");

        Task stored = service.getTask("ID3");
        assertEquals("NewName", stored.getName());
        assertEquals("NewDesc", stored.getDescription());
    }

    @Test
    void getTaskThrowsIfNotFound() {
        assertThrows(IllegalArgumentException.class,
                () -> service.getTask("MISSING"));
    }
}
