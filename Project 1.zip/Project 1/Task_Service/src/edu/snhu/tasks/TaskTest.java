package edu.snhu.tasks;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TaskTest {

    @Test
    void createsValidTask() {
        Task t = new Task("ID1", "ShortName", "Short desc");
        assertEquals("ID1", t.getTaskId());
        assertEquals("ShortName", t.getName());
        assertEquals("Short desc", t.getDescription());
    }

    @Test
    void idCannotBeNullOrTooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(null, "Name", "Desc"));
        assertThrows(IllegalArgumentException.class,
                () -> new Task("ABCDEFGHIJK", "Name", "Desc")); // 11 chars
    }

    @Test
    void nameCannotBeNullOrTooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("ID1", null, "Desc"));
        assertThrows(IllegalArgumentException.class,
                () -> new Task("ID1", "123456789012345678901", "Desc")); // 21 chars
    }

    @Test
    void descriptionCannotBeNullOrTooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("ID1", "Name", null));
        String longDesc = "123456789012345678901234567890123456789012345678901"; // 51 chars
        assertThrows(IllegalArgumentException.class,
                () -> new Task("ID1", "Name", longDesc));
    }

    @Test
    void settersEnforceRules() {
        Task t = new Task("ID2", "Name", "Desc");

        assertThrows(IllegalArgumentException.class,
                () -> t.setName("123456789012345678901")); // 21 chars

        assertThrows(IllegalArgumentException.class,
                () -> t.setDescription("123456789012345678901234567890123456789012345678901")); // 51 chars
    }

    @Test
    void idIsNotUpdatable() {
        Task t = new Task("FIXED", "Name", "Desc");
        t.setName("Other");
        t.setDescription("Other desc");

        assertEquals("FIXED", t.getTaskId());
    }
}
